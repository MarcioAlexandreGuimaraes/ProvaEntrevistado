﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace Prova2Bim.Dominio.Entidades
{ 

	public class Entrevistado;
		{

	public Entrevistado()
           {
                 }

			public Entrevistado(string nome, int idade, string cpf, bool empregado, string descricao, bool aluguel, int telefone)
			{
			
				this.nome = nome;
				this.idade = idade;
				this.empregado = empregado;
				this.descricao = descricao;
	            this.aluguel = aluguel;
		        this.telefone = telefone
			}



            public string nome { get; private set; }
            public int idade { get; private set;  }
			public string cpf { get; private set; }
            public bool empregado { get; private set; }
			public string descricao { get; private set; }
			public bool aluguel { get; private set; }
	        
	        public int telefone { get; private set; }
		}

	

