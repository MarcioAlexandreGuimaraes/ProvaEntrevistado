﻿using Projeto.Domain.Entidades;
using Prova2Bim.Dominio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova2Bim.Dominio.Interfaces
{

    internal class IEntrevistadoService
    {
		public void Adicionar(Entrevistado Entrevistado);
		public void Atualizar(Entrevistado Entrevistado);

		public List<Entrevistado> ObterTodos();
		public Entrevistado ObterPoridade(int idade);
		public Entrevistado ObterPorEmpregado(bool empregado);

		public Entrevistado ObterPorDescricao(string descricao);

		public Entrevistado ObterPorAluguel(string aluguel);

		public Entrevistado ObterporTelefone(int telefone);


	}
}
