﻿using Microsoft.AspNetCore.Mvc;

namespace Prova2Bim.API.Controllers
{
    public class EntrevistadoController
	{
        
    [ApiController]
		[Route("[controller]")]
		public class EntrevistadoController : Controller
		{
			private readonly IEntrevistadoService _entrevistadoService;

			public EntrevistadoController(IEntrevistadoService entrevistadoservice)
			{
				_entrevistadoservice = entrevistadoservice;
			}

			[HttpGet("api/entrevistado/obter-todos")]
			public IActionResult ObterTodos()
			{
				var listaentrevistados = _entrevistadoService.ObterTodos();

				if (_entrevistadoService is null) return NotFound("Nenhum Entrevistado encontrado");

				return Ok(listaentrevistado);
			}

			[HttpGet("api/entrevistado/obter-por-idade/{idade}")]
			public IActionResult ObterPorIdade(int idade)
			{
				var entrevistado = _entrevistado.ObterPorId(idade);

				if (entrevistado is null) return NotFound("idade  não encontrado");

				return Ok(entrevistado);
			}

			[HttpGet("api/entrevistado/obter-por-cpf/{cpf}")]
			public IActionResult ObterPorCpf(string cpf)
			{
				var entrevistado = _entrevistadoService.ObterPorCpf(cpf);

				if (entrevistado is null) return NotFound("CPF não encontrado");

				return Ok(cpf);
			}

			[HttpGet("api/entrevistado/obter-por-descricao/{descricao}")]
			public IActionResult ObterPorDescricao(string descricao)
			{
				Entrevistado entrevistado = _entrevistadoService.ObterPorDescricao(descricao);

				if (descricao is null) return NotFound(" Nenhuma descricao informada");

				return Ok(descricao);
			}



			[HttpPost("api/aluno/adicionar")]
			public IActionResult Adicionar(NovoEntrevistadoRequest novoEntrevistadoRequest)
			{
				_entrevistadoService.Adicionar(
					EntrevistadoFactory.NovoEntrevistado(
						novoEntrevistadoRequest.nome,
						novoEntrevistadoRequest.idade,
						novoEntrevistadoRequest.cpf,
						novoEntrevistadoRequest.empregado,
				        novoEntrevistadoRequest.descricao,
				       novoEntrevistadoRequest.email,
					   novoEntrevistadoRequest.aluguel,
					   novoEntrevistadoRequest.telefone
					));

				return Ok(" Entrevistado inserido com sucesso");
			}

			[HttpPut("api/Entrevistado/adicionar")
			public IActionResult Atualizar(AtualizarEntrevistadoRequest atualizarEntrevistadoRequest)
			{
				_entrevistadoService.Atualizar(
					EntrevistadoFactory.EntrevistadoExistente(
					
						novoEntrevistadoRequest.nome,
						novoEntrevistadoRequest.idade,
						novoEntrevistadoRequest.cpf,
						novoEntrevistadoRequest.empregado,
						novoEntrevistadoRequest.descricao,
					   novoEntrevistadoRequest.email,
					   novoEntrevistadoRequest.aluguel,
					   novoEntrevistadoRequest.telefone
					)
				   );
				return Ok("Entrevistado atualizado com sucesso");

			}
		}
	}
}
}
